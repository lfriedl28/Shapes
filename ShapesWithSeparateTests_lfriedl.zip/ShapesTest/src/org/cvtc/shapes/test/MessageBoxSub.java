package org.cvtc.shapes.test;

import org.cvtc.shapes.Dialog;

public class MessageBoxSub implements Dialog {

	public int show(){
		return 0x00;
	}

	@Override
	public int show(String message, String title) {
		// TODO Auto-generated method stub
		return 0x00;
	}
	
}
