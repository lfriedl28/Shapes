package org.cvtc.shapes;

public interface Renderer {

	public int render();
	
}
