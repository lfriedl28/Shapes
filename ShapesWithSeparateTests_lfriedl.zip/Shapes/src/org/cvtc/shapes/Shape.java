package org.cvtc.shapes;

abstract public class Shape {
	
	private Dialog MessageBox;
	
	protected Dialog getMessageBox() {
		return MessageBox;
	}
	
	private void setMessageBox(Dialog MessageBox) {
		this.MessageBox = MessageBox;
	}
	
	public Shape (Dialog MessageBox) {
		this.MessageBox = MessageBox;
	}

	public abstract float surfaceArea();
	public abstract float volume();
}
