// Package this class is inside of
package org.cvtc.shapes;

public class ShapesTest {

	// Main method that starts program
	// Also creates new instances of the shape types: Cuboid, Cylinder and Sphere
	// Taking in the appropriate dimensions for the shape
	// Then calls the render method to display the message box that displays the dimensions, volume and surface area
	public static void main(String[] args) {
		
		ShapeFactory shapeFactory = new ShapeFactory(null);
		
		Shape cuboid = shapeFactory.make(ShapeType.Cuboid);
		cuboid.render();
		
		Shape cylinder = shapeFactory.make(ShapeType.Cylinder);
		cylinder.render();
	
		Shape sphere = shapeFactory.make(ShapeType.Sphere);
		sphere.render();


	}

}
