package org.cvtc.shapes;

public enum ShapeType {
	Cylinder, Sphere, Cuboid
}
