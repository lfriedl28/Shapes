package org.cvtc.shapes;

abstract public class Shape implements Renderer {
	
	private Dialog MessageBox;
	
	protected Dialog getMessageBox() {
		return MessageBox;
	}
	
	private void setMessageBox(Dialog MessageBox) {
		this.MessageBox = MessageBox;
	}
	
	public Shape (Dialog MessageBox) {
		super();
	}

	public abstract float surfaceArea();
	
	public abstract float volume();

}
