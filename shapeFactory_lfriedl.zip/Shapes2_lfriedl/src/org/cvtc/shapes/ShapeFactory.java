package org.cvtc.shapes;

public class ShapeFactory {

	private Dialog dialog;

	private Dialog getDialog() {
		return dialog;
	}

	private void setDialog(Dialog dialog) {
		this.dialog = dialog;
	}
	
	public ShapeFactory(Dialog dialog) {
		
	}
	
	public Shape make(ShapeType type) {
		if (type == ShapeType.Cuboid) {
			return new Cuboid(null, 1, 1, 1);
		} else if (type == ShapeType.Cylinder) {
			return new Cylinder(null, 1,1);
		} else if (type == ShapeType.Sphere) {
			return new Sphere(null, 1);
		} else {
			return null;
		}
	}
	
}
